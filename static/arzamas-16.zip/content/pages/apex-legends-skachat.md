---
title: Где и как скачать 下载 Apex Legends?
author: admin
type: page
date: 2019-02-13T04:31:11+03:00
url: /apex-legends-skachat
categories:
  - apex
             
---

Apex Legends бесплатен. Его можно скачать и установить через специальное приложение лаунчер от издателя EA, который называется Origin. Для установки Apex Legends необходимо сначала скачать Origin по ссылке: [https://www.origin.com/rus/ru-ru/store/download](https://www.origin.com/rus/ru-ru/store/download), а затем зарегистрироваться в случае если у вас нет учетной записи в Origin и после этого в программе выбрать Apex Legends и нажать установить.

Для наглядности служит видеогайд:

{{< youtube 9f_93eCuERk >}}

