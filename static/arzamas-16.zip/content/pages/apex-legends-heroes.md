---
title: Персонажи в Apex Legends
author: admin
type: page
date: 2019-02-15T04:31:11+03:00
url: /apex-legends-heroes
categories:
  - apex
             
---

Всего в Apex Legends восемь персонажей. Для более подробной информации о каждом нажмите на его имя. Перед игрой желательно выучить способности какого-то одного персонажа, чтобы лучше ориентироваться в игровом процессе. Для этого служат гайды, которые содержатся в конце статей. Но важен и игровой опыт. Постепенно вы научитесь играть за разных героев и выбирать их в зависимоти от того, кого выбрали ваши партнеры по команде. Итак, список героев Apex сейчас таков:

<ul>
<li>Герои атаки: <a href="/apex-bangalore">Bangalore</a>, <a href="/apex-mirage">Mirage</a>, <a href="/apex-wraith">Wraith</a>;</li>
<li>Защитники (танки): <a href="/apex-gibraltar">Gibraltar</a>, <a href="/apex-caustic">Caustic</a>;</li>
<li>Саппорты (герои подмоги, хилы): <a href="/apex-lifeline">Lifeline</a>, <a href="/apex-pathfinder">Pathfinder</a>, <a href="/apex-bloodhound">Bloodhound</a>.</li>
</ul>

<img src="\pics\apex-characters.jpg">