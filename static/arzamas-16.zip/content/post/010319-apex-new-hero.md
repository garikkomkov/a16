---
title: Новый герой Apex Legends – Octane
author: admin
type: post
date: 2019-03-01T06:42:11+03:00
url: /apex-octane-new-hero-2
categories:
  - apex
             
---

Юзер с Reddit запостил снимок экрана с изображением одного из новых героев Apex Legends – Octane.

На картинке можно найти и описание его способностей. Пассивная способность Swift Mend восстанавливает здоровье Octane, пока он не находится в бою. Активная Adrenaline Junkie дает персонажу ускорение на 30% на 6 секунд. Ульта Launch Pad позволяет создать трамплин.

<img src="https://pp.userapi.com/c845418/v845418674/1b9299/i0XJJ7Smcoo.jpg">