---
title: Проблема в Apex Legends PersistenceReadComplete for data storage "Respawn" failed
author: admin
type: post
date: 2019-02-21T05:51:11+03:00
url: /apex-legends-PersistenceReadComplete
categories:
  - apex
             
---

Сегодня многие игроки столкнулись с проблемой, игра долго грузится и вылетает с ошибкой "Disconnect: PersistenceReadComplete for data storage "Respawn" failed". К сожалению, разработчини не учли, что в Apex Legends будет играть одновременно такое большое количество людей как сейчас, поэтому бывают случаи, что сервера просто не справляются с нагрузкой. 

Как же быть простому геймеры в такой ситуации? Как решить проблему? Ответ плавает на поверхности: нужно просто ждать. Еще вариант: поменять сервер. У некоторых игроков при смене региона происходило подключение к игре. Но не увлекайтесь. На серверах в странах удаленный от РФ пинги будут выше, следовательно попасть в соперника будет сложнее.

Статус серверов в Apex Legends можно проверить по ссылке: https://gamingintel.com/server-down-status/apex-legends/