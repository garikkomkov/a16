---
title: В Apex Legends - новый мировой рекорд по одиночным убийствам
author: admin
type: post
date: 2019-02-20T04:41:11+03:00
url: /apex-legends-mirovoj-record-mendokusaii
categories:
  - apex
             
---

В бесплатным баттл-рояле Apex Legends установили новый мировой рекорд по одиночным убийствам. Это сделал стример Mendokusaii вчера вечером. Он совершил 36 убийств за 18 минут, при этом нанес 5460 урона. 

Он побил рекорд MrSimple, который несколько дней назад совершил 34 убийства. Видео по теме:

{{< youtube RREZYcnQq0U >}}