---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
draft: true
toc: false
comments: false
categories:
- category1
- category2
tags:
- tag1
- tag2
---


<!--more-->
