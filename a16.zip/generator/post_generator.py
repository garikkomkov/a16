# https://storage.yandexcloud.net/sarov/2019/01/02-concert/01.jpg
#start_link = input('start link is: ')
#print(start_link)
from datetime import datetime
import os

def write_to_file(filename, content, mode='w'):
    with open(filename, encoding="utf-8", mode=mode) as f:
        f.write(content)
		
def generate_front(title, url, filename='post2.md'):
    month = datetime.now().strftime('%m')
    day = datetime.now().strftime('%d')
    year = datetime.now().strftime('%Y')
    content = '''---
title: '''+ title + '''
disable_profile: true
disable_widgets: true
author: admin
description:
type: post
date: '''+year+'-'+month+'-'+day+'''T04:31:11+03:00
url: /'''+ url + '''.html
banner: https://storage.yandexcloud.net/sarov/2022/banners/banner-'''+ url +'''.jpg
tags:
  - mobile-photo
  
---
'''
    write_to_file(filename, content,'w')
    
    

month = datetime.now().strftime('%m')
day = datetime.now().strftime('%d')
year = datetime.now().strftime('%Y')

total = int(input('How many images: '))
universal_name=input('Plese enter url like rashirenie: ')
url=universal_name
filename=year+'-'+month+'-'+day+'-'+universal_name+'.md'
prefix=input('plz, enter S3 directory prefix (ex: 04/17-stadion): ')
title=input('Введите заголовок записи: ')
start_link = '![](https://storage.yandexcloud.net/sarov/2022/'+prefix+'/'

write_to_file(filename, '')  # rewrites

generate_front(title, url, filename)
r = []
i = 1
while i<10:
    r.append('\n'+start_link + '0'+str(i)+'.jpg)\n')
    write_to_file(filename, r[i-1], mode='a')
    #print (r[i-1])
    i+=1
j=10
r.append('\n')
while j<=total+1:
    r.append(start_link + str(j)+'.jpg)\n\n')
    #print (r[j-1])
    write_to_file(filename, r[j-1], mode='a')
    j+=1
blogpostspath="C:\\soft\\hugo\\sarovname\\content\\posts\\"
os.rename(filename,blogpostspath+filename)
print(blogpostspath+filename)