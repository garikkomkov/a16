# Генерирует файлы в markdown разметке исходя из данных, полученных после запроса к БД

import sqlite3
from datetime import datetime
import os

def write_to_file(filename, content, mode='w'):
    with open(filename, encoding="utf-8", mode=mode) as f:
        f.write(content)

def generate_post(title, url, descr, fulltext, day, month, year):
    # month = datetime.now().strftime('%m')
    # day = datetime.now().strftime('%d')
    # year = datetime.now().strftime('%Y')
    filename = day+'-'+month+'-'+year+'__'+url+'.md'
    content = '''---
title: '''+ title + '''
author: admin
description: ''' + descr + '''
type: post
date: '''+year+'-'+month+'-'+day+'''T04:31:11+03:00
url: /'''+ url + '-'+ day+'-'+month+'-'+year+'''.html
tags:
  - саров
  
---

''' + fulltext

    write_to_file(filename, content,'w')
    
db = sqlite3.connect('a16news.db')

#create cursor

c = db.cursor()
c.execute("""SELECT rowid, title, fulltext, description, day, month, year from a16news
ORDER BY rowid desc
""")
result = c.fetchall()
for post in result:
    rowid = str(post[0])
    title = post[1]
    fulltext = post[2]
    descr = post[3]
    day = post[4]
    month = post[5]
    year = post[6]
    print("id: "+rowid)
    print("title: "+title)
    print("fulltext: "+fulltext)
    print("descr: "+descr)
    generate_post(title, rowid, descr, fulltext, day, month, year)

db.close()

# c.execute("""CREATE TABLE news (
   # id integer PRIMARY KEY,
   # title text,
   # full_text text,
   # yandex text,
   # hashtag text,
   # imagelink text
# )""")