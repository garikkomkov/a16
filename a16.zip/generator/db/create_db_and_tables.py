# создает нужную нам БД

import sqlite3

db = sqlite3.connect('a16news.db')

#create cursor

c = db.cursor()
c.execute("""CREATE TABLE a16news (   
   title text,
   fulltext text,
   description text,
   hashtag text,
   imagelink text,
   source text,
   day text,
   month text,
   year text
)""")

db.commit()
db.close()

# c.execute("""CREATE TABLE news (
   # id integer PRIMARY KEY,
   # title text,
   # full_text text,
   # yandex text,
   # hashtag text,
   # imagelink text
# )""")