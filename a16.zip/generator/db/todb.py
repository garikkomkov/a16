# Добавляет записи в БД
# В консоль вставляем полностью текст поста, скрипт разбивает его на заголовок и остальной текст и вставляет 
import sqlite3
from datetime import datetime


def find_hashtag(stroka):
    slova = stroka.split()
    for slovo in slova:
        if(slovo[0]=="#" and slovo!="#Главное"):
            return(slovo.replace("#",""))
            
def to_db(newsid, fulltext, c):
    # db = sqlite3.connect(dbname)
    # c = db.cursor()
    hashtag = "саров"    
    # ищем заголовок, разделитель здесь точка и пробел после точки
    rawstroki = fulltext.split(". ")
    stroki = [x for x in rawstroki if x]
    title = stroki[0]
    description = stroki[1]
    print("title: "+title)
    print("desc: "+description)
    day = datetime.now().strftime('%d')
    month = datetime.now().strftime('%m')
    year = datetime.now().strftime('%Y')
    
    i=1
    
    imagelink=str(newsid)+".jpg"
    print(imagelink)
    source = ""
    # c.execute(""" INSERT INTO news (id, fulltext) VALUES (?, ?)""",(newsid, fulltext))
    c.execute(""" INSERT OR REPLACE INTO a16news (title, fulltext, description, hashtag, imagelink, source, day, month, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",(title, fulltext, description, hashtag, imagelink, source, day, month, year))
    db.commit()
    
    
newsid="3975"
fulltext=input("Введите запись полностью, которую нужно добавить в БД: ")
dbname="a16news.db"
db = sqlite3.connect(dbname)
c = db.cursor()
to_db(newsid, fulltext, c)
db.close()


'''
fulltext="""Воду из родника «Хитрый» пить нельзя!
Фото: Яндекс Дзен

Межрегиональное управление № 50 ФМБА России информирует, что по  
результатам проведенного анализа пробы воды из источника «Поселок Хитрый» не соответствует требованиям санитарного законодательства по исследуемым микробиологическим показателям и данную воду употреблять в питьевых целях не рекомендуется.

#ОБЩЕСТВО"""


'''