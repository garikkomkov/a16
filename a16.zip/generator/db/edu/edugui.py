from tkinter import *

root = Tk()

'''
label = Label(root, text="I am a label widget")
button = Button(root, text="I am a button")

label.pack()
button.pack()
'''
'''
frame = Frame(root)
Label(frame, text="Pack Demo of side and fill").pack()
Button(frame, text="A").pack(side=LEFT, fill=Y)
Button(frame, text="B").pack(side=TOP, fill=X)
Button(frame, text="C").pack(side=RIGHT, fill=NONE)
Button(frame, text="D").pack(side=LEFT, fill=BOTH)
frame.pack()

Label(root, text="Pack Demo of expand").pack()
Button(root, text="I do not expand").pack()
Button(root, text="I do not fill x but I expand").pack(expand = 1)
Button(root, text="I fill and expand").pack(fill=X, expand = 1)
'''
'''
parent = Frame(root)
Button(parent, text="ALL IS WELL").pack(fill=X)
Button(parent, text="Back to basics").pack(fill=X)
Button(parent, text="Catch me if u can").pack(fill=X)

Button(parent, text="LEFT").pack(side=LEFT)
Button(parent, text="CENTER").pack(side=LEFT)
Button(parent, text="RIGHT").pack(side=LEFT, expand = 1)

parent.pack()
'''

Label(root, text="Username").grid(row=0, sticky=W)
Label(root, text="Password").grid(row=1, sticky=W)
Entry(root).grid(row=0, column=1, sticky=E)
Entry(root).grid(row=1, column=1, sticky=E)
Button(root, text="Login").grid(row=2,column=1, sticky=NSEW)
root.mainloop()