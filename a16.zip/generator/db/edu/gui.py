from tkinter import *

def Call():
    num = entry_box.get()
    output_box["text"] = "Коты хотят кушать!"
    msg = Label(window, text = "You pressed the button!"+num)
    msg.place(x=30,y=50)
    button["bg"] = "blue"
    button["fg"] = "white"
    
    
window = Tk()
window.title("Добавляем записи в БД")
window.geometry("800x600")
# кнопка
button = Button(text="Press me", command = Call)
button.place(x=300, y=400, width = 200, height= 100)

# поле ввода-вывода
entry_box = Entry(text=0)
entry_box.place(x=100,y=0,width = 200, height= 100)


# message поле
output_box = Message(text=0)
output_box["bg"] = "blue"
output_box["fg"] = "white"
output_box["relief"] = "sunken"
output_box.place(x=200,y=200, width = 200, height= 100)

answer = output_box["text"]


#listbox

list_box = Listbox()
list_box.place(x=300,y=300, width = 200, height= 100)

window.mainloop()