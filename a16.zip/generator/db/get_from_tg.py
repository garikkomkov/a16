# запрашивает посты, содержащие текст и изображение с телеграм канала и добавляет их в БД
import sqlite3
import json
import os
import sys
import random
from telethon.sync import TelegramClient
from telethon import connection
from datetime import date, datetime
# from todb import to_db


# классы для работы с каналами
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch

# класс для работы с сообщениями
from telethon.tl.functions.messages import GetHistoryRequest
def find_hashtag(stroka):
    slova = stroka.split()
    for slovo in slova:
        if(slovo[0]=="#" and slovo!="#Главное"):
            return(slovo.replace("#",""))

def write_to_file(filename, content, mode='w'):
    with open(filename, encoding="utf8", mode=mode) as f:
        f.write(content)
       
api_id = 2004572
api_hash = '8a217a6e765f9a97ceb9a4d9b1ea2bee'
client = TelegramClient('anon', api_id, api_hash)

client.start()

async def dump_all_messages(channel,start,db):
	
	offset_msg = 0    # номер записи, с которой начинается считывание
	c = db.cursor()    # номер записи, с которой начинается считывание
	limit_msg = 30   # максимальное число записей, передаваемых за один раз

	all_messages = []   # список всех сообщений
	total_messages = 0 # https://docs.telethon.dev/en/latest/modules/client.html#telethon.client.messages.MessageMethods.iter_messages 
	total_count_limit = 0  # поменяйте это значение, если вам нужны не все сообщения

	class DateTimeEncoder(json.JSONEncoder):
		'''Класс для сериализации записи дат в JSON'''
		def default(self, o):
			if isinstance(o, datetime):
				return o.isoformat()
			if isinstance(o, bytes):
				return list(o)
			return json.JSONEncoder.default(self, o)

	while True:
		history = await client(GetHistoryRequest(
			peer=channel,
			offset_id=offset_msg,
			offset_date=None, 
            add_offset=0,
			limit=limit_msg,
            max_id=0,
            min_id=start, 
			hash=0))
		if not history.messages:
			break
		messages = history.messages
		k=0 # счетчик цикла
		for message in messages: # скачиваем сообщение из телеграм-канала, сохраняем в файлы id.txt и id.jpg текст и картинку соответственно
			all_messages.append(message.to_dict())
			id=message.id
			# пишем в лог файл write_to_file("log.txt",str(id)+"\n","a")
			k+=1
			if (k==1):
                                write_to_file("id.txt",str(id)) # записываем в файл последний id, который удалось получить с телеграм канала
			if message.photo and message.raw_text:
                            with open(str(id)+'.txt', 'w', encoding='utf8') as outfile:
                                outfile.write(message.raw_text)
                            imagelink=str(id)+'.jpg'
                            fulltext=message.raw_text
                            hashtag = find_hashtag(fulltext)
                            rawstroki = fulltext.split("\n")
                            stroki = [x for x in rawstroki if x]
                            print(stroki)
                            title=stroki[0]
                            print("Заголовок: "+title)
                            i=1
                            ozvuchka=""
                            while(i<len(stroki)-1):
                                if(stroki[i].find("Фото:")==-1 and stroki[i].find("http")==-1):
                                    ozvuchka+=stroki[i]+" "
                                i+=1
                            yandex=title+". "+ozvuchka
                            print("Yandex: "+yandex)
                            c.execute(""" INSERT OR REPLACE INTO audionews (id, title, fulltext, yandex, hashtag, imagelink) VALUES (?, ?, ?, ?, ?, ?)""",(id, title, fulltext, yandex, hashtag, imagelink))
                            db.commit()
                                
                            path = await client.download_media(message)
                            new_path=".\\pics\\"+str(id)+".jpg"
                            new_txt_path=".\\text\\"+str(id)+".txt"
                            if (os.path.exists(new_path)):
                                os.remove(new_path)
                            os.rename(path, new_path)
                            if (os.path.exists(new_txt_path)):
                                os.remove(new_txt_path)
                            os.rename(str(id)+".txt", new_txt_path)
                            #draw(id)
                            #random.seed()
                            #strrandom=str(random.randint(1,1000))
                            #os.rename(new_path,strrandom+"-"+str(id)+".jpg")
                            #os.rename(str(id)+'.txt',strrandom+"-"+str(id)+".txt")
                            with open('channel_photo_path.txt', 'w', encoding='utf8') as outfile:
                                outfile.write(path)  # printed after download is done
		offset_msg = messages[len(messages) - 1].id
		db.close()
		total_messages = len(all_messages)		
		if total_count_limit != 0 and total_messages >= total_count_limit:
			break

	with open('channel_messages.json', 'w', encoding='utf8') as outfile:
		 json.dump(all_messages, outfile, ensure_ascii=False, cls=DateTimeEncoder)


async def main():

    db = sqlite3.connect('news.db')

    #create cursor

    c = db.cursor()
    c.execute(""" SELECT * from audionews ORDER BY id DESC
    """)

    startid = c.fetchone()[0] # получаем последний id, который есть в базе
    #startid = 4262 # для пустой базы руками устанавливаем id
    print("Начинаем получать новости начиная с "+str(startid)) #
    url = "https://t.me/sarovrf"
    channel = await client.get_entity(url)
    await dump_all_messages(channel,startid-10,db)    
    
    db.close()

with client:
	client.loop.run_until_complete(main())