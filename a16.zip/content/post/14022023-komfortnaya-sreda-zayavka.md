---
title: Администрация Сарова вновь направит заявку на Всероссийский конкурс лучших проектов формирования комфортной городской среды
author: admin
type: post
draft: false
date: 2023-02-14T02:42:11+03:00
url: /komfortnaya-sreda-zayavka
categories:
  - строительство
  
---

В 2023 году администрация Сарова вновь направит заявку на Всероссийский конкурс лучших проектов формирования комфортной городской среды. Саров дважды становился победителем этого конкурса, благодаря чему получил гранты на обновление парка имени Зернова и детского парка на улице Сосина.

<img src="https://sun9-west.userapi.com/sun9-3/s/v1/ig2/p1JEV6CK2bZebM37r5uNMVJuZTyH6LRFH8p4bJfRIdsmKoLMedujx051L8ERmVsaKcJuxx8kyiLTkShsyy65ztJe.jpg?size=2560x1810&quality=95&type=album"> 

Общий объем привлеченных средств превысил 200 миллионов рублей. Объект для заявки на предстоящий конкурс определят граждане. Для этого городская администрация запустила опрос, который проходит с 9 по 27 февраля в социальной сети ВКонтакте.

<!--more-->

<img src="https://sun9-east.userapi.com/sun9-58/s/v1/ig2/oLu5rHkwTnU0olLogyey2q8Qj4TZh-lVF9NKTW4DuC50CcqfYK17eAr1BTkWSbxnt5ka7TBKEAS0T42X7CI6nPRt.jpg?size=2560x1810&quality=95&type=album"> 

<img src="https://sun9-east.userapi.com/sun9-23/s/v1/ig2/6v97d4RCXUhW5iCcjtzqEOUaSutUfVtCvTTDCjZeMI6WqkciMjO-3y2CTO4W8QR8bTQryz5BdER9r3dihuC95Snq.jpg?size=2560x1810&quality=95&type=album"> 

